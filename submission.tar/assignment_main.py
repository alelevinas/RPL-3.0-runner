from main import hello_world
# tu codigo
hello_world()